
var app = angular.module("myApp",['ngRoute'])


.config(['$routeProvider', function($routeProvider){
  $routeProvider.
    when('/Route1',{
      templateUrl: 'student.html',
      controller:'StudentController'
    })
    .when('/Route2',{
      templateUrl: 'course.html',
      controller:'CourseController'
    })

     .when('/Route3',{
      templateUrl: 'students.html',
      controller:'itController'
    })
    .when('/Route4',{
      templateUrl: 'followers.html',
      controller:'FollowerController'
    }).

   
   otherwise({redirectTo:'/Route1'})
}]);



app.controller('itController', ['$scope', '$http', function($scope, $http){
  $http.get('https://api.github.com/users/amarfamt/repos').then(function(response){
    $scope.st = response.data;
    $scope.s=response.status;
    $scope.l=response.statusText;

  });
}])


app.controller("StudentController",function($scope)
{
$scope.sname="First Second Surname";
$scope.course="Angularjs";
});

app.controller("CourseController",function($scope)
{

$scope.courses=["Angularjs","WebX","DevOps"];

});


app.controller('FollowerController', ['$scope', '$http', function($scope, $http){
  $http.get('https://api.github.com/users/amarfamt/followers').then(function(response){
    $scope.data = response.data;
    $scope.s=response.status;
    $scope.l=response.statusText;

  });
}])










